package Random;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Scanner;

public class Hanma {

	public static void main(String[] args) throws IOException {
		int arr[]= {1,2,3,4,5,6,7,8,9,0};
		BufferedWriter bu=new BufferedWriter(new FileWriter("output/text.txt"));
		char []arr1= {'��','Ů'};
		Scanner sc=new Scanner(System.in);
		System.out.print("�������������������");
		int nextInt = sc.nextInt();
		LinkedList<String>aLinkedList=new LinkedList<String>();
		File file=new File("input/");
		
		String[] list = file.list();
		
		//������Ӧ���ļ����
		ArrayList<String> input = input("input/"+list[0]);
		ArrayList<String> input2 = input("input/"+list[1]);
		ArrayList<String> input3 = input("input/"+list[2]);
		ArrayList<String> input4 = input("input/"+list[3]);
		LinkedList<String>aLinkedList2=new LinkedList<String>();
		for(int i=0;i<nextInt;i++) {
			String string="1";
			//�ֻ�����
			for(int j=1;j<=10;j++) {
				int n=(int)(Math.random()*10);
				
				if(n!=10) {
					string+=arr[n];
				}
				else {
					j--;
				}
			}
			if(!aLinkedList.contains(string)) {
				String string2="2017";
				for(int j=1;j<=6;j++) {
					int m= (int)(Math.random()*10);
					if(m!=10) {
						string2+=arr[m];
					}else {
						j--;
					}
				}
				
				
				//�Ա�
				string+=","+string2;
				int k=(int)(Math.random()*2);
				while (k==2) {
					k=(int)(Math.random()*2);
					
				}
				string+=","+arr1[k];
				
				
				
				
				
				//ѧԺ
				k=(int)(Math.random()*input3.size());
				while(k==input3.size())k=(int)(Math.random()*input3.size());
				string+=","+input3.get(k);
				
				
				//רҵ
				k=(int)(Math.random()*input4.size());
				while(k==input4.size())k=(int)(Math.random()*input4.size());
				string+=","+input4.get(k);
				
				
				
				//��+��
				k=(int)(Math.random()*input.size());
				String string3=input.get(k);
				k=(int)(Math.random()*input.size());
				string3+=input2.get(k);
				while(aLinkedList2.contains(string3)) {
					string3="";
					k=(int)(Math.random()*input.size());
					string3=input.get(k);
					k=(int)(Math.random()*input.size());
					string3+=input2.get(k);
				}
				
				
				
				string+=","+string3;
				aLinkedList.add(string);
			}
		}
		
		
		
		
		
		
		for(String s:aLinkedList) {
			
			bu.write(s+"\n");
			System.out.println(s);
		}
		bu.close();

	}
	
	//�ļ����ݶ�ȡ
	public static ArrayList<String> input(String path) throws IOException{
		ArrayList<String>arrayList=new ArrayList<String>();
		BufferedReader bufferedReader = new BufferedReader(new FileReader(path));
		String readLine = bufferedReader.readLine();
		while(readLine!=null) {
			arrayList.add(readLine);
			readLine = bufferedReader.readLine();
		}
		bufferedReader.close();
		return arrayList;
	}

}

